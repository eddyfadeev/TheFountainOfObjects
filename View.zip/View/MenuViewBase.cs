﻿using Services.Interfaces;
using View.Layout;

namespace View;

public abstract class MenuViewBase : IUpdatesLayout
{
    public ILayoutManager LayoutManager { get; } = new LayoutManager();

    public abstract string MenuName { get; }
}