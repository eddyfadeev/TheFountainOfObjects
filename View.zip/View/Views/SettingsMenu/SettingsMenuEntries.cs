﻿namespace View.SettingsMenu;

public enum SettingsMenuEntries
{
    
    ChangePlayerName,
    FieldSize,
    Pits,
    Maelstroms,
    Amaroks,
    Arrows,
    Back
}