﻿global using System;
global using System.Collections.Generic;
global using static Services.Utilities.Utilities;
global using Spectre.Console;
global using System.ComponentModel.DataAnnotations;